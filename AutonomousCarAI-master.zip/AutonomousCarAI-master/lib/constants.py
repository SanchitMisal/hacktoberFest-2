
keyList = []
for char in "ABCDEFGHIJKLMNOPQRSTUVWXYZ 123456789,.'£$/\\":
    keyList.append(char)

    
w = [1,0,0,0]
s = [0,1,0,0]
a = [0,0,1,0]
d = [0,0,0,1]